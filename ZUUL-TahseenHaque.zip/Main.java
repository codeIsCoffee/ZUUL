class Main {
  public static void main(String[] args) {
   Game newGame = new Game(); 
   newGame.play();
  }
}